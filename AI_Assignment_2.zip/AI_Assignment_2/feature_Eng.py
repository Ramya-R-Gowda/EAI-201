# =========================================================
#  TASK 2 – MODEL BUILDING & TRAINING (FIFA ASSIGNMENT)
# =========================================================

import os
import pandas as pd
import numpy as np
import re
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from imblearn.over_sampling import SMOTE
import joblib

# ---------- CONFIG ----------
PROJECT_DIR = r"C:\Users\Hp\OneDrive\Desktop\AI_assign_FIFA"
FEATURE_FILE = os.path.join(PROJECT_DIR, "cleaned_data", "merged_fifa_data_cleaned.csv")
LABEL_FILE = os.path.join(PROJECT_DIR, "cleaned_data", "final_48_teams_cleaned.csv")
OUTPUT_DIR = os.path.join(PROJECT_DIR, "Cleaned output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ---------- 1. LOAD DATA ----------
print("Loading datasets...")
features = pd.read_csv(FEATURE_FILE, low_memory=False)
labels = pd.read_csv(LABEL_FILE)
print("Datasets loaded successfully!")
print("Feature file shape:", features.shape)
print("Label file shape:", labels.shape)

# ---------- 2. DETECT TEAM COLUMNS ----------
def detect_team_column(df, name="file"):
    for col in df.columns:
        if "team" in col.lower():
            print(f"Detected team column in {name}: {col}")
            return col
    print(f"ERROR: No Team-like column found in {name}.")
    return None

feat_team_col = detect_team_column(features, "features")
label_team_col = detect_team_column(labels, "labels")

features.rename(columns={feat_team_col: "Team"}, inplace=True)
labels.rename(columns={label_team_col: "Team"}, inplace=True)

# ---------- 3. NORMALIZE TEAM NAMES ----------
def normalize_name(name):
    if pd.isna(name):
        return ""
    name = str(name).lower()
    name = re.sub(r"[^a-z]", "", name)
    return name.strip()

features["Team_norm"] = features["Team"].apply(normalize_name)
labels["Team_norm"] = labels["Team"].apply(normalize_name)

# ---------- 4. CREATE TARGET COLUMN ----------
features["Finalist"] = features["Team_norm"].apply(
    lambda x: 1 if x in labels["Team_norm"].values else 0
)

print("Target column 'Finalist' created successfully!")
print("Positive samples (Finalists):", features["Finalist"].sum())

if features["Finalist"].sum() == 0:
    print("\nWARNING: No Finalist matches found. Check team name formats!")
    print("Example feature names:", features["Team"].unique()[:10])
    print("Example label names:", labels["Team"].unique()[:10])
    exit()

# ---------- 5. SELECT FEATURES ----------
possible_features = [
    "rank", "points", "win", "loss", "draw",
    "goals_for", "goals_against", "goal_difference",
    "matches_played", "year"
]
use_cols = [c for c in possible_features if c in features.columns]

if not use_cols:
    print("No predefined features found. Selecting top correlated numeric features...")
    numeric_cols = features.select_dtypes(include=[np.number]).drop(columns=["Finalist"]).columns
    corr = features[numeric_cols].corrwith(features["Finalist"]).abs().sort_values(ascending=False)
    use_cols = corr.head(10).index.tolist()

print("Selected features:", use_cols)

X = features[use_cols].fillna(0)
y = features["Finalist"].astype(int)

# ---------- 6. TRAIN/TEST SPLIT ----------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(f"\nOriginal class distribution: {np.bincount(y_train)}")

# ---------- 7. APPLY SMOTE (BALANCING) ----------
print("Applying SMOTE to balance the training dataset...")
smote = SMOTE(random_state=42)
X_res, y_res = smote.fit_resample(X_train, y_train)
print(f"Balanced class distribution after SMOTE: {np.bincount(y_res)}")

# ---------- 8. SCALE FEATURES ----------
scaler = StandardScaler()
X_res_scaled = scaler.fit_transform(X_res)
X_test_scaled = scaler.transform(X_test)

# ---------- 9. TRAIN MODELS ----------
print("\nTraining Logistic Regression...")
logreg = LogisticRegression(max_iter=1000, random_state=42)
logreg.fit(X_res_scaled, y_res)
y_pred_lr = logreg.predict(X_test_scaled)

print("Training Random Forest...")
rf = RandomForestClassifier(n_estimators=300, max_depth=8, random_state=42)
rf.fit(X_res, y_res)
y_pred_rf = rf.predict(X_test)

# ---------- 10. EVALUATE ----------
print("\n--- MODEL PERFORMANCE ---")
print("Logistic Regression Accuracy:", round(accuracy_score(y_test, y_pred_lr), 3))
print("Random Forest Accuracy:", round(accuracy_score(y_test, y_pred_rf), 3))

print("\nLogistic Regression Report:")
print(classification_report(y_test, y_pred_lr, zero_division=0))

print("\nRandom Forest Report:")
print(classification_report(y_test, y_pred_rf, zero_division=0))

# ---------- 11. SAVE MODELS ----------
joblib.dump(logreg, os.path.join(OUTPUT_DIR, "logistic_model.pkl"))
joblib.dump(rf, os.path.join(OUTPUT_DIR, "random_forest_model.pkl"))
joblib.dump(scaler, os.path.join(OUTPUT_DIR, "scaler.pkl"))

print("\nModels saved successfully in:", OUTPUT_DIR)

# ---------- 12. SAVE PREDICTIONS ----------
pred_df = X_test.copy()
pred_df["Actual"] = y_test.values
pred_df["Pred_LR"] = y_pred_lr
pred_df["Pred_RF"] = y_pred_rf
pred_path = os.path.join(OUTPUT_DIR, "model_predictions.csv")
pred_df.to_csv(pred_path, index=False)

print(f"\nPredictions saved to {pred_path}")
print("\nTask 2 completed successfully!")
print("Proceed to Task 3: Model Evaluation and Visualization.")