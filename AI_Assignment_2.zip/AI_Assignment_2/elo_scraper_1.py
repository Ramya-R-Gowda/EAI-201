# scripts/elo_scraper_debug.py
import os
import requests
import pandas as pd
from datetime import datetime

# ========== Config ==========
URL = "https://www.eloratings.net/world.html"

# Use an absolute path to your project data folder (edit this if needed)
SAVE_DIR = r"C:\Users\Hp\OneDrive\Desktop\AI_Assignment_2\elo_ratings"
os.makedirs(SAVE_DIR, exist_ok=True)

def fetch_html(url):
    print("Fetching:", url)
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
    print("HTTP status code:", r.status_code)
    r.raise_for_status()
    return r.text

def main():
    print("Current working directory:", os.path.abspath(os.getcwd()))
    print("Save directory (absolute):", os.path.abspath(SAVE_DIR))
    # Fetch HTML
    html = fetch_html(URL)
    # show a small preview so you can confirm the page returned HTML
    print("\n--- HTML preview (first 800 chars) ---")
    print(html[:800])
    print("\n--- End HTML preview ---\n")

    # try to parse tables
    try:
        tables = pd.read_html(html)
    except Exception as e:
        print("pd.read_html() raised exception:", e)
        tables = []

    print(f"Found {len(tables)} table(s) on the page.")
    if not tables:
        print("No tables found — cannot save. Check the HTML preview above.")
        return

    # take first table as ratings
    df = tables[0]
    print("Raw table shape:", df.shape)
    print(df.head(6))

    # basic cleaning (optional)
    df.columns = [str(c).strip() for c in df.columns]
    if 'Team' not in df.columns:
        # try to find likely team column
        print("Columns detected:", df.columns.tolist())

    # Save files with timestamp
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join(SAVE_DIR, f"elo_ratings_2025_{ts}.csv")
    xlsx_path = os.path.join(SAVE_DIR, f"elo_ratings_2025_{ts}.xlsx")
    df.to_csv(csv_path, index=False)
    try:
        df.to_excel(xlsx_path, index=False)
    except Exception as e:
        print("Could not write xlsx (check openpyxl):", e)

    print(f"\nSaved CSV to: {csv_path}")
    print(f"Saved XLSX to: {xlsx_path} (if supported)")

    # List the directory contents so you can immediately see files
    print("\nFiles in SAVE_DIR:")
    for fname in sorted(os.listdir(SAVE_DIR)):
        full = os.path.join(SAVE_DIR, fname)
        print(fname, "-", os.path.getsize(full), "bytes")

if __name__ == "__main__":
    main()
